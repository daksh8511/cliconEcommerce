import React from "react";
import BlackFirday from "./Components/Header/BlackFirday";
import Header from "./Components/Header/Header";
import BottomNav from "./Components/BottomNav/BottomNav";
import Banner from "./Components/Banner/Banner";
import Features from "./Components/Features/Features";
import TodayBestDeal from "./Components/TodayBestDeal/TodayBestDeal";
import ShopWithCategory from "./Components/ShopWithCategory/ShopWithCategory";
import FeaturedProduct from "./Components/FeaturedProduct/FeaturedProduct";
import TwoBanner from "./Components/TwoBanner/TwoBanner";
import LatestNews from "./Components/LatestNews/LatestNews";

const App = () => {
  return (
    <div>
      <div className="bg-gray-900">
        {/* <BlackFirday /> */}
      </div>
      <div className="bg-[#1B6392]">
        {/* <Header /> */}
      </div>
      <div className="container">
        {/* <BottomNav /> */}
        {/* <Banner /> */}
        {/* <Features /> */}
        {/* <TodayBestDeal /> */}
        {/* <ShopWithCategory /> */}
        {/* <FeaturedProduct /> */}
        {/* <TwoBanner /> */}
        <LatestNews />
      </div>
    </div>
  );
};

export default App;
