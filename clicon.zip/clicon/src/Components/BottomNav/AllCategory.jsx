import React from 'react'

import './AllCategory.css'

import { IoIosArrowDown, IoIosArrowForward } from "react-icons/io";

const AllCategory = () => {
  return (
    <div className='category relative bg-gray-200 p-2 z-10 duration-200 hover:bg-[#FA8232] hover:text-white cursor-pointer'>
        <div className="title flex items-center gap-2">
            <h2>All Category</h2>
            <IoIosArrowDown className='arr duration-200' />
        </div>
        <ul className='allcategories hidden absolute top-10 left-0 bg-white text-black *:p-2 *:hover:bg-gray-300'>
            <li>Computer & Laptop</li>
            <li>Computer Accessories</li>
            <li className='smartphone relative'><span className='flex justify-between'>Smartphone <IoIosArrowForward /></span>
            <div className='sidemenu hidden absolute -right-175 p-2 -bottom-84 bg-white'>
                <ul className='*:hover:bg-gray-300 *:px-5 *:py-2'>
                    <li>All</li>
                    <li>iPhone</li>
                    <li>Samsung</li>
                    <li>Realme</li>
                    <li>Xiome</li>
                    <li>Oppo</li>
                    <li>Vivo</li>
                    <li>OnePlus</li>
                    <li>Huawei</li>
                    <li>Infinix</li>
                    <li>Techno</li>
                </ul>
                <div className='featured' >
                    <h2 className='uppercase mb-3'>featured product</h2>
                    <div className="box *:mb-3 *:p-2 *:border *:border-gray-300">
                        <div className="minibox flex gap-5">
                            <div className="image">
                                <img src="https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1712137796/Croma%20Assets/Gaming/Gaming%20Consoles/Images/305985_ilpfe3.png?tr=w-360" alt="" className='w-full h-full' />
                            </div>
                            <div className="details">
                                <h3>SONY Playstation 5 Slim 1TB SSD (CFI-2008A01X, White) with ASTRO's Playroom</h3>
                                <h4 className='mt-5'>$180</h4>
                            </div>
                        </div>
                        <div className="minibox flex gap-5">
                            <div className="image">
                                <img src="https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1712137796/Croma%20Assets/Gaming/Gaming%20Consoles/Images/305985_ilpfe3.png?tr=w-360" alt="" className='w-full h-full' />
                            </div>
                            <div className="details">
                                <h3>SONY Playstation 5 Slim 1TB SSD (CFI-2008A01X, White) with ASTRO's Playroom</h3>
                                <h4 className='mt-5'>$180</h4>
                            </div>
                        </div>
                        <div className="minibox flex gap-5">
                            <div className="image">
                                <img src="https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1712137796/Croma%20Assets/Gaming/Gaming%20Consoles/Images/305985_ilpfe3.png?tr=w-360" alt="" className='w-full h-full' />
                            </div>
                            <div className="details">
                                <h3>SONY Playstation 5 Slim 1TB SSD (CFI-2008A01X, White) with ASTRO's Playroom</h3>
                                <h4 className='mt-5'>$180</h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="discount_offer">
                    <img src="https://media-ik.croma.com/prod/https://media.croma.com/image/upload/v1723573867/Croma%20Assets/Communication/Mobiles/Images/309159_0_rzdw2t.png?tr=w-360" alt="" />
                    <h2>21% Discount</h2>
                    <p>escape the noise, it's time to hear the magic with xiaomi earbuds.</p>
                    <div className="flex">
                        <span>Starting Price : </span>
                        <h3>$99 USD</h3>
                    </div>
                    <button>Shop Now</button>
                </div>
            </div>
            </li>
            <li>Headphone</li>
            <li>Mobile Accessories</li>
            <li>Gaming Console</li>
            <li>Camera & Photo</li>
            <li>TV & Home Applience</li>
            <li>Watches & Accessories</li>
            <li>GPS & Navigation</li>
            <li>Wearable Technologies</li>
        </ul>
    </div>
  )
}

export default AllCategory