import React from 'react'
import { FaPhoneVolume } from "react-icons/fa6";
import AllCategory from './AllCategory';

import { IoLocationOutline, IoInformationCircleOutline } from "react-icons/io5";
import { HiMiniArrowPathRoundedSquare } from "react-icons/hi2";
import { PiHeadphonesDuotone } from "react-icons/pi";

const BottomNav = () => {
  return (
    <section>
        <div className="container p-5 border-b border-gray-300 flex justify-between items-center">
            <div className="menu_container flex gap-5">
                <div className="category">
                    <AllCategory />
                </div>
                <div className="track_order flex items-center gap-1 p-2 duration-200 hover:bg-[#FA8232] hover:text-white cursor-pointer">
                    <IoLocationOutline />
                    <h2>Track Order</h2>
                </div>
                <div className="compare flex items-center gap-1 p-2 duration-200 hover:bg-[#FA8232] hover:text-white cursor-pointer">
                    <HiMiniArrowPathRoundedSquare />
                    <h2>Compare</h2>
                </div>
                <div className="customer_support flex items-center gap-1 p-2 duration-200 hover:bg-[#FA8232] hover:text-white cursor-pointer">
                    <PiHeadphonesDuotone />
                    <h2>Customer Support</h2>
                </div>
                <div className="need_help flex items-center gap-1 p-2 duration-200 hover:bg-[#FA8232] hover:text-white cursor-pointer">
                    <IoInformationCircleOutline />
                    <h2>Need Help</h2>
                </div>
            </div>
            <div className='flex items-center gap-2'>
                <FaPhoneVolume />
                <span>+1-202-555-0104</span>
            </div>
        </div>
    </section>
  )
}

export default BottomNav