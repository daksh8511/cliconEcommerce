import React from "react";
import { FaArrowRightLong } from "react-icons/fa6";
import './Header.css'

const BlackFirday = () => {
  return (
    <section className="container">
      <div className=" bg-gray-900 text-white flex justify-between px-5 py-1 items-center">
        <div className="title flex items-center">
            <span className="bg-[#F3DE6D] px-2 -rotate-10 me-2 text-black">Black</span>
            <h2 className="font-bold">Friday</h2>
        </div>
        <div className="discount">
            <h2 className="items-center flex gap-2">Up to <span className="text-[#EBC80C] font-bold text-4xl">59%</span>OFF</h2>
        </div>
        <div className="shop_btn">
            <button className="flex items-center gap-2 bg-[#EBC80C] text-gray-900 uppercase text-sm font-bold px-4 py-3 rounded cursor-pointer">shop now <FaArrowRightLong /></button>
        </div>
      </div>
    </section>
  );
};

export default BlackFirday;
