import React from "react";

import {
  FaTwitter,
  FaFacebook,
  FaPinterestP,
  FaInstagram,
} from "react-icons/fa6";
import { FiSearch } from "react-icons/fi";
import { CiShoppingCart } from "react-icons/ci";
import { FaUser } from "react-icons/fa";

import logo from "/assets/Logo.png";

const Header = () => {
  return (
    <section className="container">
      <div className="text-white p-5 border-b flex items-center justify-between">
        <h5 className="text-sm">Welcome to Clicon online eCommerce store.</h5>
        <div className="flex items-center">
          <div className="follow flex items-center gap-2">
            <h4>Follow us:</h4>
            <div className="flex gap-4 *:cursor-pointer">
              <FaTwitter />
              <FaFacebook />
              <FaPinterestP />
              <FaInstagram />
            </div>
          </div>
          <span className="border border-gray-200 h-[25px] mx-5"></span>
          <select name="" id="" className="*:text-black mr-4 outline-none">
            <option value="Eng">Eng</option>
            <option value="HIN">HIN</option>
            <option value="SPN">SPN</option>
          </select>
          <select name="" id="" className="*:text-black outline-none">
            <option value="USD">USD</option>
            <option value="INR">INR</option>
            <option value="EUR">EUR</option>
            <option value="AUD">AUD</option>
          </select>
        </div>
      </div>
      <div className="p-5 flex justify-between items-center">
        <div className="companyIcon">
          <img src={logo} alt="" className="w-30" />
        </div>
        <div className="search bg-white flex items-center p-2 w-90 justify-between rounded">
          <input
            type="text"
            placeholder="Search for anything...."
            className="w-full outline-0"
          />
          <FiSearch />
        </div>
        <div className="cart_user flex gap-5 items-center">
            <div className="cart text-white relative cursor-pointer">
                <CiShoppingCart className="text-3xl" />
                <span className="absolute text-sm bg-white text-black px-2 rounded-full -top-2 -right-2">1</span>
            </div>
            <div className="user cursor-pointer">
                <FaUser className="text-white text-2xl" />
            </div>
        </div>
      </div>
    </section>
  );
};

export default Header;
