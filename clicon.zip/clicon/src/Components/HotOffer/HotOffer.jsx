import React from 'react'

const HotOffer = () => {
  return (
    <div className='bg-red-500 py-1 w-1/4 text-center mb-2 text-sm font-bold text-white'>Hot</div>
  )
}

export default HotOffer